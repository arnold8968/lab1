Bonus Questions:

This folder does not contain any mapper and reducer files. Rather, there is only a PDF of the report for the bonus questions.

The report offers insight as to how we would have gone about performing the MapReduce algorithms.
